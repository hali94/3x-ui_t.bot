"""Initial schema — creates all tables and enum types from scratch.

Revision ID: 000_initial_schema
Revises:
Create Date: 2026-06-30
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "000_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── Enum types ───────────────────────────────────────────────────────────
    userrole_enum = postgresql.ENUM(
        "ADMIN", "RESELLER", "RESELLER_L1", "RESELLER_L2", "CUSTOMER",
        name="userrole",
    )
    userrole_enum.create(op.get_bind(), checkfirst=True)

    userstatus_enum = postgresql.ENUM(
        "ACTIVE", "INACTIVE", "BANNED",
        name="userstatus",
    )
    userstatus_enum.create(op.get_bind(), checkfirst=True)

    resellerlevel_enum = postgresql.ENUM(
        "LEVEL_1", "LEVEL_2",
        name="resellerlevel",
    )
    resellerlevel_enum.create(op.get_bind(), checkfirst=True)

    resellerstatus_enum = postgresql.ENUM(
        "ACTIVE", "INACTIVE", "SUSPENDED",
        name="resellerstatus",
    )
    resellerstatus_enum.create(op.get_bind(), checkfirst=True)

    customerstatus_enum = postgresql.ENUM(
        "ACTIVE", "EXPIRED", "DISABLED", "TRAFFIC_EXHAUSTED",
        name="customerstatus",
    )
    customerstatus_enum.create(op.get_bind(), checkfirst=True)

    subscriptionstatus_enum = postgresql.ENUM(
        "ACTIVE", "EXPIRED", "CANCELLED", "RENEWED",
        name="subscriptionstatus",
    )
    subscriptionstatus_enum.create(op.get_bind(), checkfirst=True)

    notificationtype_enum = postgresql.ENUM(
        "EXPIRY_WARNING", "TRAFFIC_80", "TRAFFIC_90", "TRAFFIC_100",
        "SUBSCRIPTION_CREATED", "SUBSCRIPTION_RENEWED", "CREDIT_ADDED",
        "L2_RESELLER_CREATED", "L2_SALE", "L2_CREDIT_LOW", "SYSTEM",
        name="notificationtype",
    )
    notificationtype_enum.create(op.get_bind(), checkfirst=True)

    notificationstatus_enum = postgresql.ENUM(
        "PENDING", "SENT", "FAILED",
        name="notificationstatus",
    )
    notificationstatus_enum.create(op.get_bind(), checkfirst=True)

    # ── users ────────────────────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("telegram_id", sa.BigInteger, nullable=False, unique=True),
        sa.Column("username", sa.String(255), nullable=True),
        sa.Column("full_name", sa.String(512), nullable=False),
        sa.Column(
            "role",
            sa.Enum("ADMIN", "RESELLER", "RESELLER_L1", "RESELLER_L2", "CUSTOMER", name="userrole"),
            nullable=False,
            server_default="CUSTOMER",
        ),
        sa.Column(
            "status",
            sa.Enum("ACTIVE", "INACTIVE", "BANNED", name="userstatus"),
            nullable=False,
            server_default="ACTIVE",
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_telegram_id", "users", ["telegram_id"])

    # ── servers ──────────────────────────────────────────────────────────────
    op.create_table(
        "servers",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("name", sa.String(255), nullable=False, unique=True),
        sa.Column("xui_url", sa.String(512), nullable=False),
        sa.Column("xui_username", sa.String(255), nullable=False),
        sa.Column("xui_password_encrypted", sa.Text, nullable=False),
        sa.Column("default_inbound_id", sa.Integer, nullable=True),
        sa.Column("active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ── resellers ────────────────────────────────────────────────────────────
    op.create_table(
        "resellers",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "user_id",
            sa.Integer,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
        ),
        sa.Column(
            "parent_reseller_id",
            sa.Integer,
            sa.ForeignKey("resellers.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "level",
            sa.Enum("LEVEL_1", "LEVEL_2", name="resellerlevel"),
            nullable=False,
            server_default="LEVEL_1",
        ),
        sa.Column("credit_gb", sa.Numeric(14, 3), nullable=False, server_default="0"),
        sa.Column("used_gb", sa.Numeric(14, 3), nullable=False, server_default="0"),
        sa.Column("allocated_to_children_gb", sa.Numeric(14, 3), nullable=False, server_default="0"),
        sa.Column("buy_price_per_gb", sa.Numeric(14, 2), nullable=False, server_default="0"),
        sa.Column("sell_price_per_gb", sa.Numeric(14, 2), nullable=False, server_default="0"),
        sa.Column("max_child_resellers", sa.Integer, nullable=False, server_default="10"),
        sa.Column("commission_percent", sa.Numeric(5, 2), nullable=False, server_default="0"),
        sa.Column(
            "status",
            sa.Enum("ACTIVE", "INACTIVE", "SUSPENDED", name="resellerstatus"),
            nullable=False,
            server_default="ACTIVE",
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_resellers_user_id", "resellers", ["user_id"])
    op.create_index("ix_resellers_parent_reseller_id", "resellers", ["parent_reseller_id"])

    # ── customers ────────────────────────────────────────────────────────────
    op.create_table(
        "customers",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("telegram_id", sa.BigInteger, nullable=True),
        sa.Column(
            "reseller_id",
            sa.Integer,
            sa.ForeignKey("resellers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("name", sa.String(512), nullable=False),
        sa.Column("email", sa.String(512), nullable=False, unique=True),
        sa.Column("uuid", sa.String(36), nullable=False, unique=True),
        sa.Column("protocol", sa.String(50), nullable=False, server_default="vless"),
        sa.Column("volume_gb", sa.Numeric(12, 3), nullable=False),
        sa.Column("used_gb", sa.Numeric(12, 3), nullable=False, server_default="0"),
        sa.Column("expire_date", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "status",
            sa.Enum("ACTIVE", "EXPIRED", "DISABLED", "TRAFFIC_EXHAUSTED", name="customerstatus"),
            nullable=False,
            server_default="ACTIVE",
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_customers_telegram_id", "customers", ["telegram_id"])
    op.create_index("ix_customers_reseller_id", "customers", ["reseller_id"])
    op.create_index("ix_customers_email", "customers", ["email"])
    op.create_index("ix_customers_uuid", "customers", ["uuid"])

    # ── subscriptions ────────────────────────────────────────────────────────
    op.create_table(
        "subscriptions",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "customer_id",
            sa.Integer,
            sa.ForeignKey("customers.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "reseller_id",
            sa.Integer,
            sa.ForeignKey("resellers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "server_id",
            sa.Integer,
            sa.ForeignKey("servers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("volume_gb", sa.Numeric(12, 3), nullable=False),
        sa.Column("price", sa.Numeric(14, 2), nullable=False),
        sa.Column("start_date", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("expire_date", sa.DateTime(timezone=True), nullable=False),
        sa.Column("xui_client_id", sa.String(36), nullable=False),
        sa.Column("inbound_id", sa.Integer, nullable=False),
        sa.Column(
            "status",
            sa.Enum("ACTIVE", "EXPIRED", "CANCELLED", "RENEWED", name="subscriptionstatus"),
            nullable=False,
            server_default="ACTIVE",
        ),
        sa.Column("link", sa.String(2048), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_subscriptions_customer_id", "subscriptions", ["customer_id"])
    op.create_index("ix_subscriptions_reseller_id", "subscriptions", ["reseller_id"])
    op.create_index("ix_subscriptions_server_id", "subscriptions", ["server_id"])
    op.create_index("ix_subscriptions_xui_client_id", "subscriptions", ["xui_client_id"])

    # ── sales ────────────────────────────────────────────────────────────────
    op.create_table(
        "sales",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "reseller_id",
            sa.Integer,
            sa.ForeignKey("resellers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "customer_id",
            sa.Integer,
            sa.ForeignKey("customers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "subscription_id",
            sa.Integer,
            sa.ForeignKey("subscriptions.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("gb", sa.Numeric(14, 3), nullable=False),
        sa.Column("buy_price_per_gb", sa.Numeric(14, 2), nullable=False, server_default="0"),
        sa.Column("sell_price_per_gb", sa.Numeric(14, 2), nullable=False, server_default="0"),
        sa.Column("amount", sa.Numeric(16, 2), nullable=False),
        sa.Column("profit", sa.Numeric(16, 2), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_sales_reseller_id", "sales", ["reseller_id"])
    op.create_index("ix_sales_customer_id", "sales", ["customer_id"])
    op.create_index("ix_sales_subscription_id", "sales", ["subscription_id"])

    # ── notifications ────────────────────────────────────────────────────────
    op.create_table(
        "notifications",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "user_id",
            sa.Integer,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "type",
            sa.Enum(
                "EXPIRY_WARNING", "TRAFFIC_80", "TRAFFIC_90", "TRAFFIC_100",
                "SUBSCRIPTION_CREATED", "SUBSCRIPTION_RENEWED", "CREDIT_ADDED",
                "L2_RESELLER_CREATED", "L2_SALE", "L2_CREDIT_LOW", "SYSTEM",
                name="notificationtype",
            ),
            nullable=False,
        ),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column(
            "status",
            sa.Enum("PENDING", "SENT", "FAILED", name="notificationstatus"),
            nullable=False,
            server_default="PENDING",
        ),
        sa.Column("reference_id", sa.Integer, nullable=True),
        sa.Column("reference_type", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_notifications_user_id", "notifications", ["user_id"])
    op.create_index("ix_notifications_reference_id", "notifications", ["reference_id"])

    # ── audit_logs ───────────────────────────────────────────────────────────
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "user_id",
            sa.Integer,
            sa.ForeignKey("users.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("action", sa.String(255), nullable=False),
        sa.Column("ip", sa.String(64), nullable=True),
        sa.Column("data", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_audit_logs_user_id", "audit_logs", ["user_id"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])


def downgrade() -> None:
    op.drop_table("audit_logs")
    op.drop_table("notifications")
    op.drop_table("sales")
    op.drop_table("subscriptions")
    op.drop_table("customers")
    op.drop_table("resellers")
    op.drop_table("servers")
    op.drop_table("users")

    postgresql.ENUM(name="notificationstatus").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="notificationtype").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="subscriptionstatus").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="customerstatus").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="resellerstatus").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="resellerlevel").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="userstatus").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="userrole").drop(op.get_bind(), checkfirst=True)
